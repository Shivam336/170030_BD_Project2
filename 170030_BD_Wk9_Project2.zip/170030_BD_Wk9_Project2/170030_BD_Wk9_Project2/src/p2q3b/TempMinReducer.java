package p2q3b;

/**
 * Question 3 b : Find top 10 cold temperature
 * 
 * Reducer Class of finding top 10 cold temperature
 * 
 * @author Shivam Singhal (06-10-2019)
 */

import java.io.IOException; 
import java.util.Map; 
import java.util.TreeMap; 

import org.apache.hadoop.io.DoubleWritable; 
import org.apache.hadoop.io.Text; 
import org.apache.hadoop.mapreduce.Reducer; 

public class TempMinReducer extends Reducer<Text,DoubleWritable, DoubleWritable, Text> { 

	private TreeMap<Double, String> tmap2; 

	@Override
	public void setup(Context context) throws IOException,InterruptedException { 
		tmap2 = new TreeMap<Double, String>(); 
	} 

	@Override
	public void reduce(Text key, Iterable<DoubleWritable> values,Context context) throws IOException, InterruptedException{ 

		String name = key.toString(); 
		double count = 0; 

		for (DoubleWritable val : values) { 
			count = val.get(); 
		} 

		tmap2.put(count, name); 
		if (tmap2.size() > 10){ 
			tmap2.remove(tmap2.firstKey()); 
		} 
	} 

	@Override
	public void cleanup(Context context) throws IOException,InterruptedException { 

		for (Map.Entry<Double, String> entry : tmap2.entrySet())  { 

			double count = entry.getKey(); 
			String name = entry.getValue(); 
			context.write(new DoubleWritable(count), new Text(name)); 
		} 
	} 
}