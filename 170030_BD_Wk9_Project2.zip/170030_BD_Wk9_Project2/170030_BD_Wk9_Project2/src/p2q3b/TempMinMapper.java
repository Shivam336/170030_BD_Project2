package p2q3b;

/**
 * Question 3 b : Find top 10 cold temperature
 * 
 * Mapper Class of finding top 10 cold temperature
 * 
 * @author Shivam Singhal (06-10-2019)
 */

import java.io.*; 
import java.util.*; 
import org.apache.hadoop.io.Text; 
import org.apache.hadoop.io.DoubleWritable; 
import org.apache.hadoop.mapreduce.Mapper; 

public class TempMinMapper extends Mapper<Object,Text, Text, DoubleWritable> { 

	private TreeMap<Double, String> tmap; 

	@Override
	public void setup(Context context) throws IOException,InterruptedException { 
		tmap = new TreeMap<Double, String>(); 
	} 

	@Override
	public void map(Object key, Text value,Context context) throws IOException,InterruptedException { 

		String[] tokens = value.toString().split(","); 
		String date = tokens[1]; 
		double tempmin = Double.parseDouble(tokens[6]); 
		tmap.put(tempmin, date); 
		if (tmap.size() > 10) { 
			tmap.remove(tmap.lastKey()); 
		} 
	} 

	@Override
	public void cleanup(Context context) throws IOException,InterruptedException { 
		for (Map.Entry<Double, String> entry : tmap.entrySet())  { 

			double count = entry.getKey(); 
			String name = entry.getValue(); 

			context.write(new Text(name), new DoubleWritable(count)); 
		} 
	} 
}