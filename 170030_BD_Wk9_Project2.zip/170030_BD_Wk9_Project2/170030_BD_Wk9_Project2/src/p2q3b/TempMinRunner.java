package p2q3b;

/**
 * Question 3 b : Find top 10 cold temperature
 * 
 * Runner Class of finding top 10 cold temperature
 * 
 * @author Shivam Singhal (06-10-2019)
 */

import org.apache.hadoop.conf.Configuration; 
import org.apache.hadoop.fs.Path; 
import org.apache.hadoop.io.DoubleWritable; 
import org.apache.hadoop.io.Text; 
import org.apache.hadoop.mapreduce.Job; 
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat; 
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat; 
import org.apache.hadoop.util.GenericOptionsParser; 

public class TempMinRunner { 

	public static void main(String[] args) throws Exception { 
		Configuration conf = new Configuration(); 
		String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs(); 

		// if less than two paths  
		// provided will show error 
		if (otherArgs.length < 2)  { 
			System.err.println("Need to enter two paths"); 
			System.exit(2); 
		} 

		Job job = Job.getInstance(conf, "top 10 Min"); 
		job.setJarByClass(TempMinRunner.class); 

		job.setMapperClass(TempMinMapper.class); 
		job.setReducerClass(TempMinReducer.class); 

		job.setMapOutputKeyClass(Text.class); 
		job.setMapOutputValueClass(DoubleWritable.class); 

		job.setOutputKeyClass(DoubleWritable.class); 
		job.setOutputValueClass(Text.class); 

		FileInputFormat.addInputPath(job, new Path(otherArgs[0])); 
		FileOutputFormat.setOutputPath(job, new Path(otherArgs[1])); 

		System.exit(job.waitForCompletion(true) ? 0 : 1); 
	}
}