package p2q2;

/**
 * Question 2: Find out hot and cold temperature
 * 
 * Mapper Class of finding hot and cold temperature
 * 
 * @author Shivam Singhal (06-10-2019)
 */

import java.io.*; 
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text; 
import org.apache.hadoop.mapreduce.Mapper; 
  
public class HotColdMapper extends Mapper<LongWritable, Text, Text, Text> { 
    @Override
    public void map(LongWritable arg0, Text Value, Context context)throws IOException, InterruptedException{ 
  
        String[] tokens = Value.toString().split(","); 
        String date = tokens[1]; 
        float temp_max = Float.parseFloat(tokens[5]);
        float temp_min = Float.parseFloat(tokens[6]);
  
        if (temp_max > 35.0) {
			// Hot day
			context.write(new Text("Hot Day " + date),new Text(String.valueOf(temp_max)));
		}
		
		if (temp_min < 10) {
			// Cold day
			context.write(new Text("Cold Day " + date),new Text(String.valueOf(temp_min)));
		}
    }  
}