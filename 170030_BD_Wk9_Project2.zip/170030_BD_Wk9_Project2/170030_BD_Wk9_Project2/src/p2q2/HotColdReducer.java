package p2q2;

/**
 * Question 2: Find out hot and cold temperature
 * 
 * Reducer Class of finding hot and cold temperature
 * 
 * @author Shivam Singhal (06-10-2019)
 */

import java.io.IOException; 
import java.util.Iterator;
import org.apache.hadoop.io.Text; 
import org.apache.hadoop.mapreduce.Reducer; 
  
public class HotColdReducer extends Reducer<Text, Text, Text, Text>{ 
  
	public void reduce(Text Key, Iterator<Text> Values, Context context)
			throws IOException, InterruptedException {
		
		String temperature = Values.next().toString();
		context.write(Key, new Text(temperature));
	}

}