package p2q2;

/**
 * Question 2: Find out hot and cold temperature
 * 
 * Runner Class of finding hot and cold temperature
 * 
 * @author Shivam Singhal (06-10-2019)
 */

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;


public class HotColdRunner {
	public static void main(String[] args) throws Exception {

		//reads the default configuration of cluster from the configuration xml files
		Configuration conf = new Configuration();

		//Initializing the job with the default configuration of the cluster		
		Job job = new Job(conf, "Hot Cold Temperature");

		//Assigning the driver class name
		job.setJarByClass(HotColdRunner.class);

		//Key type coming out of mapper
		job.setMapOutputKeyClass(Text.class);

		//value type coming out of mapper
		job.setMapOutputValueClass(Text.class);

		//Defining the mapper class name
		job.setMapperClass(HotColdMapper.class);

		//Defining the reducer class name
		job.setReducerClass(HotColdReducer.class);

		//Defining input Format class which is responsible to parse the dataset into a key value pair
		job.setInputFormatClass(TextInputFormat.class);

		//Defining output Format class which is responsible to parse the dataset into a key value pair
		job.setOutputFormatClass(TextOutputFormat.class);

		//Configuring the input path from the file-system into the job
		FileInputFormat.addInputPath(job, new Path(args[0]));

		//Configuring the output path from the file-system into the job
		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		//exiting the job only if the flag value becomes false
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}

}
