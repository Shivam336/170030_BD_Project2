package p2q1;

/**
 * Question 1: Find out highest temperature of each year.
 * 
 * Mapper Class of finding highest temperature of each year.
 * 
 * @author Shivam Singhal (06-10-2019)
 */

import java.io.*; 
import java.util.*; 

import org.apache.hadoop.io.Text; 
import org.apache.hadoop.io.DoubleWritable; 
import org.apache.hadoop.mapreduce.Mapper; 

public class YearHighTempMapper extends Mapper<Object, Text, Text, DoubleWritable> { 

	private TreeMap<Double, String> tmap;
	private TreeMap<Double, String> tmap3; 
	private TreeMap<Double, String> tmap11;
	private TreeMap<Double, String> tmap12;
	private TreeMap<Double, String> tmap13;
	private TreeMap<Double, String> tmap14;
	private TreeMap<Double, String> tmap15;
	private TreeMap<Double, String> tmap16;
	private TreeMap<Double, String> tmap17;
	private TreeMap<Double, String> tmap19; 
	private TreeMap<Double, String> tmapMain; 

	@Override
	public void setup(Context context) throws IOException, 
	InterruptedException 
	{ 
		tmap = new TreeMap<Double, String>(Collections.reverseOrder()); 
		tmap3 = new TreeMap<Double, String>(Collections.reverseOrder()); 
		tmap11 = new TreeMap<Double, String>(Collections.reverseOrder());
		tmap12 = new TreeMap<Double, String>(Collections.reverseOrder());
		tmap13 = new TreeMap<Double, String>(Collections.reverseOrder());
		tmap14 = new TreeMap<Double, String>(Collections.reverseOrder());
		tmap15 = new TreeMap<Double, String>(Collections.reverseOrder());
		tmap16 = new TreeMap<Double, String>(Collections.reverseOrder());
		tmap17 = new TreeMap<Double, String>(Collections.reverseOrder());
		tmap19 = new TreeMap<Double, String>(Collections.reverseOrder());
		tmapMain = new TreeMap<Double, String>(Collections.reverseOrder());
	} 

	@Override
	public void map(Object key, Text value,Context context) throws IOException, InterruptedException { 
		String[] tokens = value.toString().split(","); 
		String date = tokens[1];
		double temp_max = Double.parseDouble(tokens[5]); 
		tmap.put(temp_max, date);        
	} 

	@Override
	public void cleanup(Context context) throws IOException, InterruptedException { 
		for(Double i:tmap.keySet()) {
			String vale =tmap.get(i);
			String ds=vale.substring(0,4);

			if(tmap3.containsValue("2011")==false)
				tmap3.put(i, ds);

			else if(tmap3.containsValue("2012")==false)
				tmap3.put(i, ds);

			else if(tmap3.containsValue("2013")==false)
				tmap3.put(i, ds);

			else if(tmap3.containsValue("2014")==false)
				tmap3.put(i, ds);

			else if(tmap3.containsValue("2015")==false)
				tmap3.put(i, ds);

			else if(tmap3.containsValue("2016")==false)
				tmap3.put(i, ds);

			else if(tmap3.containsValue("2017")==false)
				tmap3.put(i, ds);

			else if(tmap3.containsValue("2019")==false)
				tmap3.put(i, ds);

		}


		for(Double j:tmap3.keySet()) {
			String vale2=tmap3.get(j);



			if(vale2.equals("2011")) {
				tmap11.put(j,vale2);
				//For 15
				double va15=tmap11.firstKey();
				String va215=tmap11.get(va15);
				tmapMain.put(va15, va215);
			}

			else if(vale2.equals("2012")) {
				tmap12.put(j,vale2);
				//For 15
				double va15=tmap12.firstKey();
				String va215=tmap12.get(va15);
				tmapMain.put(va15, va215);
			}

			else if(vale2.equals("2013")) {
				tmap13.put(j,vale2);
				//For 15
				double va15=tmap13.firstKey();
				String va215=tmap13.get(va15);
				tmapMain.put(va15, va215);
			}

			else if(vale2.equals("2014")) {
				tmap14.put(j,vale2);
				//For 15
				double va15=tmap14.firstKey();
				String va215=tmap14.get(va15);
				tmapMain.put(va15, va215);
			}

			else if(vale2.equals("2015")) {
				tmap15.put(j,vale2);
				//For 15
				double va15=tmap15.firstKey();
				String va215=tmap15.get(va15);
				tmapMain.put(va15, va215);
			}

			else if(vale2.equals("2016")) {
				tmap16.put(j,vale2);
				//For 15
				double va15=tmap16.firstKey();
				String va215=tmap16.get(va15);
				tmapMain.put(va15, va215);
			}

			else if(vale2.equals("2017")) {
				tmap17.put(j,vale2);
				//For 15
				double va15=tmap17.firstKey();
				String va215=tmap17.get(va15);
				tmapMain.put(va15, va215);
			}

			else if(vale2.equals("2019")) {
				tmap19.put(j,vale2);
				//For 19
				double va19=tmap19.firstKey();
				String va219=tmap19.get(va19);
				tmapMain.put(va19, va219);
			}

		}

		for(Double j:tmapMain.keySet()) {
			String vale2=tmapMain.get(j);
			context.write(new Text(vale2), new DoubleWritable(j)); 
		}
	} 
}