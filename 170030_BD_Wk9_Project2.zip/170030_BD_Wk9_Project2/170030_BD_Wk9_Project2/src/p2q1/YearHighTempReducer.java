package p2q1;

/**
 * Question 1: Find out highest temperature of each year.
 * 
 * Reducer Class of finding highest temperature of each year.
 * 
 * @author Shivam Singhal (06-10-2019)
 */

import java.io.IOException; 
import java.util.Map; 
import java.util.TreeMap; 

import org.apache.hadoop.io.DoubleWritable; 
import org.apache.hadoop.io.Text; 
import org.apache.hadoop.mapreduce.Reducer; 

public class YearHighTempReducer extends Reducer<Text,Text, Text, DoubleWritable> { 

	private TreeMap<Double, String> tmap2; 

	@Override
	public void setup(Context context) throws IOException,InterruptedException { 
		tmap2 = new TreeMap<Double, String>(); 
	} 

	public void reduce(Text key, Iterable<DoubleWritable> values,Context context) throws IOException, InterruptedException { 

		String name = key.toString(); 
		double count = 0; 

		for (DoubleWritable val : values) { 
			count = val.get(); 
		} 
		tmap2.put( count,name); 
	} 

	@Override
	public void cleanup(Context context) throws IOException,InterruptedException { 
		for (Map.Entry<Double, String> entry : tmap2.entrySet())  { 
			double name = entry.getKey(); 
			String count = entry.getValue(); 
			context.write(new Text(count),new DoubleWritable(name)); 
		} 
	} 
}