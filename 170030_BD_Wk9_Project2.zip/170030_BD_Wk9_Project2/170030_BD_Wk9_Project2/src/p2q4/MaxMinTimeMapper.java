package p2q4;

/**
 * Question 4 : Find maximum and minimum temperature along with data.
 * 
 * Mapper Class of finding maximum and minimum temperature along with data.
 * 
 * @author Shivam Singhal (06-10-2019)
 */

import java.io.*; 
import java.util.*; 
import org.apache.hadoop.io.Text; 
import org.apache.hadoop.io.LongWritable; 
import org.apache.hadoop.mapreduce.Mapper; 

public class MaxMinTimeMapper extends Mapper<Object,Text, Text, LongWritable> { 

	private TreeMap<Long, String> tmap; 

	@Override
	public void setup(Context context) throws IOException,InterruptedException { 
		tmap = new TreeMap<Long, String>(); 
	} 

	@Override
	public void map(Object key, Text value, Context context) throws IOException,InterruptedException { 

		String[] tokens = value.toString().split(","); 
		String temp = "Max:   "+tokens[5]+"   |   "+"Min:   "+tokens[6]; 
		long date = Long.parseLong(tokens[1]); 

		tmap.put(date, temp); 
	} 

	@Override
	public void cleanup(Context context) throws IOException, InterruptedException { 
		for (Map.Entry<Long, String> entry : tmap.entrySet())  { 
			long count = entry.getKey(); 
			String name = entry.getValue(); 

			context.write(new Text(name), new LongWritable(count)); 
		} 
	} 
}